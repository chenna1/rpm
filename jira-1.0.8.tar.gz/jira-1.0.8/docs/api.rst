API Documentation
*****************

.. module:: jira

.. contents:: Contents
   :local:

JIRA
====

.. autoclass:: JIRA

Priority
========

.. autoclass:: Priority

Comment
=======

.. autoclass:: Comment

Worklog
=======

.. autoclass:: Worklog

Watchers
========

.. autoclass:: Watchers

JIRAError
=========

.. autoclass:: JIRAError
