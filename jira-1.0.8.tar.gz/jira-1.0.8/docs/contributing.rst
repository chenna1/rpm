Contributing
************

The client is an open source project under the BSD license. Contributions of any kind are welcome!

https://github.com/pycontribs/jira/

If you find a bug or have an idea for a useful feature, file it at that bitbucket project. Extra points for source
code patches -- fork and send a pull request.

Discussion and support
======================

We encourage all who wish to discuss by using https://answers.atlassian.com/questions/topics/754366/jira-python

Keep in mind to use the jira-python tag when you add a new question. This will assure that the project mantainers
will get notified about your question.
